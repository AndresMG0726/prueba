## Nombre del proyecto

Agendas digitales Inhaus

## Integrantes
	Rodrigo Andrey Araya Castro
	Ernesto Andrés Hernández Naranjo
	Andrés Esteban Mora García
	Mario Rodriguez Loria

## Descripción 

Agenda digitales Inhaus va a tener diferentes módulos o acciones que fueron 
solicitadas directamente por el cliente para su desarrollo, primeramente el sistema va a 
contar un acceso por login en el cual se va a necesitar el correo de cada empleado de 
Inhaus junto con una contraseña creada por los desarrolladores que puede ser 
cambiada por cada empleado después de su primer acceso al sistema. 
Cada asesor va a tener la libertad de agendar su cita con los leads (posibles clientes) 
de manera libre, va a poder agendar esta misma con los siguientes datos necesarios 
pedidos por el cliente: Id de la propiedad, Nombre del lead, teléfono del lead, oficina a la 
cual pertenece, costo de comisión de la propiedad, correo del cliente(opcional), fecha y 
hora. Estos son los campos requeridos por ahora, estos pueden llegar a cambiar. 
Contara con una parte para modificar la cita y eliminarla (Cada ingreso de una cita y 
eliminación van a llevar un contar por pedido del cliente para llevar un seguimiento de 
estas). Los asesores van a recibir un correo de confirmación de la cita cuando se 
agenda esta misma a sus correos de la empresa junto con alertas de acercamiento a la 
fecha establecida. 
Los clientes (Dueños de casas y proyectos) van atener un acceso en el cual se le va a 
proporcionar un usuario y una contraseña para que ellos también tengan acceso a 
cuantas citas se han agendado en su propiedad (Esto fue propuesto por el cliente pero 
no esta establecido oficialmente). Los clientes cuando se agrega su coreo cuando se 
agenda una cita en su propiedad les llegara un correo electrónico con el aviso. 
IN01 DOCUMENTO DE ALCANCE Y ACEPTACIÓN 4
Los administradores son los que van a tener mayor acceso claro esta pero son los que 
van a poder ver la mayor cantidad de información de importancia para la empresa. Los 
administradores van a poder visualizar cuantas citas en total se hicieron mensualmente 
por cada asesor inmobiliario con el numero de propiedad y la comisión de esta misma, 
junto con la cantidad en total de citas de todos los asesores juntas por oficinas (todos 
los asesores de la empresa) y también por oficinas para llevar un mayor orden y no 
tener datos de importancia confundidos (oficina de Cartago, Este, Oeste y Sur). Estos 
son los únicos que pueden agregar un nuevo asesor al sistema para que pueda dar uso 
del mismo como también son los únicos que pueden modificar y eliminar su información 
básica, pero no pueden cambiar nada en las citas ya agendadas por el asesor ya que el 
único que puede cambiar la información de las citas es el asesor mismo. 
Tecnologías necesarias: 
- Computadora con Windows 10, safari o Linux 
- Acceso a internet

## Modulos

	Módulo de asesores   	
	Módulo de Administradores
	Módulo de autentificación
	Módulo jefe de oficina
	Módulo de cliente


## Tecnologias utilizadas
	HTML 
	JavaScript 
	Bootstrap 
	Laravel
	MySQL
	
## Cómo instalar el repositorio en el equipo para desarrollo
	$ git clone link_repositorio
	$ cd nombre_del_repositorio/app
	$ npm install
	$ ionic serve
