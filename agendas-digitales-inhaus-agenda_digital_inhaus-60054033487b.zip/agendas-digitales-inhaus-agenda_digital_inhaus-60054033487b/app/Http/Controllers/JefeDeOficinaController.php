<?php

namespace App\Http\Controllers;
use App\Models\Citas;
use App\Models\User;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Auth;

class JefeDeOficinaController extends Controller
{
    function index(){
        $events = array();
        $usuarioLogueado = Auth::user()->sede;
        $usuarioSede = Auth::user()->id;
        $filtroAsesores = User::where('role', '=', '2')->where('sede', '=', $usuarioLogueado)->get();
        $citas = Citas::where('sede', '=', $usuarioLogueado)->when(request(key:'user_id'),function($query){
            $usuarioLogueado = auth()->user()->sede;
            return $query->where('user_id', request(key: 'user_id'));
        })->get();

       foreach($citas as $cita){
        $events[]= [
            'id' => $cita->id,
            'title' => $cita->nombreLead,
            'telefono' => $cita->telefono,
            'correo' => $cita->correo,
            'idPropiedades' => $cita->idPropiedades,
            'color' => $cita->color,
            'start' => $cita->inicio,
            'end' => $cita->fin
        ];
       }
       return view('dashboards.jefeOficina.dashboard', ['events'=> $events, 'filtro'=>$filtroAsesores, 'usuarioLogueado'=>$usuarioLogueado]);
    }


    public function indexBuscarCitas(Request $request)
    {

        
        if($request) {
            $query = trim($request->get(key:'search'));
            $usuarioLogueado = auth()->user()->id;
            $users =  Citas::where('user_id', '=', $usuarioLogueado)->where('nombreLead', 'LIKE', '%' . $query . '%')->get();

        }
 
        $usuarioLogueado = auth()->user()->id;
        $citas = Citas::where('user_id', '=', $usuarioLogueado)->paginate();
       

        return view('dashboards.jefeOficina.buscarCita',  ['users'=> $users, 'search'=> $query]);
    }


    public function store(Request $request)
    {

        $usuarioLogueado = auth()->user()->sede;

        $request->validate([

            'nombreLead' => 'required|string',
            'idPropiedades' => 'required',
            'color' => 'required',
            'inicio' => 'required',
            'fin' => 'required',
        ]);

            $citas = Citas::create([
                'nombreLead' => $request->nombreLead,
                'telefono' => $request->telefono,
                'correo' => $request->correo,
                'idPropiedades' => $request->idPropiedades,
                'color' => $request->color,
                'inicio' => $request->inicio,
                'fin' => $request->fin,
                'user_id' => Auth::id(),
                'sede' => Auth::user()->sede,
            ]);
       
        return response()->json($citas);
        
    }
}
