<?php

namespace App\Http\Controllers;
use App\Models\Citas;
use App\Models\User;
use Illuminate\Http\Request;
use Auth;

class AdminController extends Controller
{
    function index(){
        $events = array();
        $usuarioLogueado = auth()->user()->id;
        $filtroAsesores = User::where('role', '=', '2')->paginate();
        $citas = Citas::when(request(key:'user_id'),function($query){
            return $query->where('user_id', request(key: 'user_id'));
        })->get();
       foreach($citas as $cita){
        $events[]= [
            'id' => $cita->id,
            'title' => $cita->nombreLead,
            'telefono' => $cita->telefono,
            'correo' => $cita->correo,
            'idPropiedades' => $cita->idPropiedades,
            'color' => $cita->color,
            'start' => $cita->inicio,
            'end' => $cita->fin
        ];
       }
       return view('dashboards.admin.dashboard', ['events'=> $events, 'filtro'=>$filtroAsesores]);
    }
    public function store(Request $request)
    {

        $prueba = auth()->user()->id;
        $request->validate([

            'nombreLead' => 'required|string',
            'idPropiedades' => 'required',
            'color' => 'required',
            'inicio' => 'required',
            'fin' => 'required',
        ]);

            $citas = Citas::create([
                'nombreLead' => $request->nombreLead,
                'telefono' => $request->telefono,
                'correo' => $request->correo,
                'idPropiedades' => $request->idPropiedades,
                'color' => $request->color,
                'inicio' => $request->inicio,
                'fin' => $request->fin,
                'user_id' => Auth::id(),
                'sede' => Auth::user()->sede,
            ]);
       
        return response()->json($citas);
        
    }
}
