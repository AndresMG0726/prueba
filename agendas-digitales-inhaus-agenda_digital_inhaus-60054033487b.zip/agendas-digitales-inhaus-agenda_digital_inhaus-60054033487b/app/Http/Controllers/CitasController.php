<?php

namespace App\Http\Controllers;

use App\Models\Citas;
use Auth;
use Illuminate\Http\Request;
use Illuminate\Foundation\Auth\User as Authenticatable;

class CitasController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $events = array();
        $citas = Citas::all();
       foreach($citas as $cita){
        $events[]= [
            'id' => $cita->id,
            'title' => $cita->nombreLead,
            'telefono' => $cita->telefono,
            'correo' => $cita->correo,
            'idPropiedades' => $cita->idPropiedades,
            'color' => $cita->color,
            'start' => $cita->inicio,
            'end' => $cita->fin
        ];
       }
        return view('citas.index', ['events'=> $events]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        $prueba = auth()->user()->sede;
        $request->validate([

            'nombreLead' => 'required|string'

        ]);

            $citas = Citas::create([
                'nombreLead' => $request->nombreLead,
                'telefono' => $request->telefono,
                'correo' => $request->correo,
                'idPropiedades' => $request->idPropiedades,
                'color' => $request->color,
                'inicio' => $request->inicio,
                'fin' => $request->fin,
                'user_id' => Auth::id(),
                'sede' => Auth::user()->sede,
            ]);
       
        return response()->json($citas);
        
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Citas  $citas
     * @return \Illuminate\Http\Response
     */
    public function show(Citas $citas)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Citas  $citas
     * @return \Illuminate\Http\Response
     */
    public function edit(Citas $citas)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Citas  $citas
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $citas = Citas::find($id);
        if(! $citas){
            return response()->json([
                'error'=>'no se encontro la cita'
            ], 404);
        }
        $citas->update([
            'inicio' => $request->inicio,
            'fin' => $request->fin
        ]);
        
        return response()->json('Cita modificada');
    }

    public function updateDatos(Request $request, $id)
    {
        $citas = Citas::find($id);
        if(! $citas){
            return response()->json([
                'error'=>'no se encontro la cita'
            ], 404);
        }
        $citas->update([
            'nombreLead' => $request->nombreLead,
                'telefono' => $request->telefono,
                'correo' => $request->correo,
                'idPropiedades' => $request->idPropiedades,
                'color' => $request->color
        ]);
        
        return response()->json('Cita ');
    }
    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Citas  $citas
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $citas = Citas::find($id);
        if(! $citas){
            return response()->json([
                'error'=>'no se encontro la cita'
            ], 404);
        }
        $citas->delete();
        return $id;
    }
}
